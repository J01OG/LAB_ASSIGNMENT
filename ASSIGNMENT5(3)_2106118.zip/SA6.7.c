/*
JAYASH PREM
DATE:6/04/22
PROGRAM:SA6.7 WAP to find the Trace(sum of the diagonal element) of a given mxn matrix.
*/
#include<stdio.h>
int main()
{
	int i,m,j,sum;
	//for input
	printf("Enter the ORDER OF MATRIX");
		printf("\nROWS=COLOUM(m x m): ");
		scanf("%d",&m);
		
	int M1[m][m];

	
	printf("ENTER value of matix M1 with dimension %d x %d\n",m,m);	

	for(i=0;i<m;i++)
			{
			for(j=0;j<m;j++)
				{
				printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
				scanf("%d",&M1[i][j] );
				}
			}
			
	//finding trace
	for(i=0;i<m;i++)
		sum+=M1[i][i];
		
		
printf("\nMATRIX M1:\n");
		for(i=0;i<m;i++)
		{
			for(j=0;j<m;j++)
				{
					printf("%d\t",M1[i][j] );
				}
				printf("\n");
		}
		
	printf("\nTRACE OF MATRIX : %d",sum);
	
	return 0;
}
	

