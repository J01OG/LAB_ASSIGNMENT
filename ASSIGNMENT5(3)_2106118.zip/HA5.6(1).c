/*
JAYASH PREM
DATE:6/04/22
PROGRAM:HA5.6 WAP to find out the sum of the secondary diagonal elements of a matrix..
*/
#include<stdio.h>
int main()
{
	int i,m,j,sum,n;
	//for input
	printf("Enter the ORDER OF MATRIX");
		printf("\nROWS=COLOUM(m x m): ");
		scanf("%d",&m);
		
	int M1[m][m];

	
	printf("ENTER value of matix M1 with dimension %d x %d\n",m,m);	

	for(i=0;i<m;i++)
			{
			for(j=0;j<m;j++)
				{
				printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
				scanf("%d",&M1[i][j] );
				}
			}
		n=m-1;
	//finding second trace
	for(i=0;i<m;i++)
		sum+=M1[i][n--];
		
		
printf("\nMATRIX M1:\n");
		for(i=0;i<m;i++)
		{
			for(j=0;j<m;j++)
				{
					printf("%d\t",M1[i][j] );
				}
				printf("\n");
		}
		
	printf("\nSECOND TRACE OF MATRIX : %d",sum);
	
	return 0;
}
	

