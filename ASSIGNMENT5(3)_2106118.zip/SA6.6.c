/*
JAYASH PREM
DATE:6/04/22
PROGRAM: SA6.6 WAP to multiply two matrices and display it.
*/
#include<stdio.h>
int main()
{
	int i,j,m1,n1,m2,n2,k;
	//for input
	
	printf("Enter the value of rows(m) x coloum(n) for matix 1 ");
	printf("\nROWS(m): ");
		scanf("%d",&m1);
	printf("\nCOLOUM(n): ");
		scanf("%d",&n1);
	int M1[m1][n1];	
		
	printf("Enter the value of rows(m) x coloum(n) for matix 2 ");
	printf("\nROWS(m): ");
		scanf("%d",&m2);
	printf("\nCOLOUM(n): ");
		scanf("%d",&n2);
	int M2[m2][n2];
		int M3[m1][n2];
	printf("ENTER value of matix M1 with dimension %d x %d\n",m1,n1);	

	for(i=0;i<m1;i++)
			{
			for(j=0;j<n1;j++)
				{
				printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
				scanf("%d",&M1[i][j] );
				}
			}
	printf("\nENTER value of matix M2 with dimension %d x %d\n",m2,n2);	

	for(i=0;i<m2;i++)
		{
			for(j=0;j<n2;j++)
					{
					printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
					scanf("%d",&M2[i][j] );
					}	
		}
		
	//multiplicatin
	if(n1==m2)
	{
	
		for (i=0;i<m1;i++)
		{
			for(j=0;j<n2;j++)
			{
				M3[i][j]=0;
				for(k=0;k<n1;k++)
				{
					M3[i][j]+=M1[i][k]*M2[k][j];
				}
			}
		}
	}
	else
	 	printf("\nMatrix multiplication is not possible");	
	 	
	 	
	//printing
	
	printf("\nMATRIX M1:\n");
		for(i=0;i<m1;i++)
		{
			for(j=0;j<n1;j++)
				{
					printf("%d\t",M1[i][j] );
				}
				printf("\n");
		}
	
	
	printf("\nMATRIX M2:\n");
		for(i=0;i<m2;i++)
		{
			for(j=0;j<n2;j++)
				{
					printf("%d\t",M2[i][j] );
				}
				printf("\n");
		}
		
		
		printf("\nMATRIX M3(multiplied matrix):\n");
		for(i=0;i<m1;i++)
		{
			for(j=0;j<n2;j++)
				{
					printf("%d\t",M3[i][j] );
				}
				printf("\n");
		}
	return 0;
}
