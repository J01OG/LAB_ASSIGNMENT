/*
JAYASH PREM
DATE:6/04/22
PROGRAM:HA5.7 WAP to check whether a given matrix is symmetric or not.
*/
#include<stdio.h>
int main()
{
	int i,m,j;
	//for input
	printf("Enter the ORDER OF MATRIX");
		printf("\nROWS=COLOUM(m x m): ");
		scanf("%d",&m);
		
	int M1[m][m];
	int M2[m][m];

	
	printf("ENTER value of matix M1 with dimension %d x %d\n",m,m);	

	for(i=0;i<m;i++)
			{
			for(j=0;j<m;j++)
				{
				printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
				scanf("%d",&M1[i][j] );
				}
			}
	//transpose
	for(i=0;i<m;i++)
		for(j=0;j<m;j++)
			M2[i][j]=M1[j][i];
	//checking
	int flag=1;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(M1[i][j]!=M2[i][j])
			{
				flag=0;
				break;
			}
		}
	}
	
	
	printf("\nMATRIX M1:\n");
		for(i=0;i<m;i++)
		{
			for(j=0;j<m;j++)
				{
					printf("%d\t",M1[i][j] );
				}
				printf("\n");
		}
		
		printf("\n TRANSPOSE MATRIX M2:\n");
		for(i=0;i<m;i++)
		{
			for(j=0;j<m;j++)
				{
					printf("%d\t",M2[i][j] );
				}
				printf("\n");
		}
		if(flag)
			printf("THEY  ARE SYMETRICAL MATRIX");
		else
			printf("THEY ARE NOT SYMETRICAL");
			
		return 0;
	}
	
