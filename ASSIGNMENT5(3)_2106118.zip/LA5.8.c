/*
JAYASH PREM
DATE:6/04/22
PROGRAM:LA5.8 WAP to find out the transpose of a given matrix.
*/

#include<stdio.h>
int main()
{
	int i,j,m,n,sum;
	//for input
	
	printf("Enter the value of rows(m) x coloum(n)");
		printf("\nROWS(m): ");
		scanf("%d",&m);
		printf("\nCOLOUM(n): ");
		scanf("%d",&n);
		
	int M1[m][n];
	
	printf("ENTER value of matix M1 with dimension %d x %d\n",m,n);	

	for(i=0;i<m;i++)
			{
			for(j=0;j<n;j++)
				{
				printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
				scanf("%d",&M1[i][j] );
				}
			}
	
	printf("\nMATRIX M1:\n");
	for(i=0;i<m;i++)
		{
		for(j=0;j<n;j++)
			{
					printf("%d\t",M1[i][j] );
			}
			printf("\n");
		}	
	
	
	//TRANSPOSE
	
	printf("\nTRANSPOSE MATRIX M2:\n");
	int M2[n][m];
	for(j=0;j<n;j++)
		{
			for(i=0;i<m;i++)
			{
				printf("%d\t",M1[i][j]);
			}
			printf("\n");
		}

	 return 0;
}
			
