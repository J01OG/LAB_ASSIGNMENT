/*
JAYASH PREM
DATE:6/04/22
PROGRAM: SA6.5 WAP to add two matrices and display it.
*/
#include<stdio.h>
int main()
{
	int i,j,m,n;
	//for input
	
	printf("Enter the value of rows(m) x coloum(n)");
		printf("\nROWS(m): ");
		scanf("%d",&m);
		printf("\nCOLOUM(n): ");
		scanf("%d",&n);
		
	int M1[m][n];
	int M2[m][n];
	int S1[m][n];
	
	printf("ENTER value of matix M1 with dimension %d x %d\n",m,n);	

	for(i=0;i<m;i++)
			{
			for(j=0;j<n;j++)
				{
				printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
				scanf("%d",&M1[i][j] );
				}
			}
	printf("\nENTER value of matix M2 with dimension %d x %d\n",m,n);	

	for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
					{
					printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
					scanf("%d",&M2[i][j] );
					}	
		}
		
		//SUM
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
					{
						S1[i][j]=M1[i][j]+M2[i][j];
					}	
		}
		printf("\nMATRIX M1:\n");
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
				{
					printf("%d\t",M1[i][j] );
				}
				printf("\n");
		}
	
	
	printf("\nMATRIX M2:\n");
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
				{
					printf("%d\t",M2[i][j] );
				}
				printf("\n");
		}
		
		printf("\nSUM OF MATRIX M1 AND M2 :\n");
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
				{
					printf("%d\t",S1[i][j] );
				}
				printf("\n");
		}
		return 0;
	}
