/*
JAYASH PREM
DATE:6/04/22
PROGRAM:HA5.8 WAP to check whether a given matrix is orthogonal or not.
*/
#include<stdio.h>
int main()
{
	int i,m,j,k,n;
	//for input
	printf("Enter the ORDER OF MATRIX");
		printf("\nROWS=COLOUM(m x m): ");
		scanf("%d",&m);
		
	int M1[m][m];
	int M2[m][m];
	
	printf("ENTER value of matix M1 with dimension %d x %d\n",m,m);	

	for(i=0;i<m;i++)
			{
			for(j=0;j<m;j++)
				{
				printf("ENTER THE VALUE OF [%d][%d] : ",i+1,j+1);
				scanf("%d",&M1[i][j] );
				}
			}
	//transpose
		for(i=0;i<m;i++)
			for(j=0;j<m;j++)
				M2[i][j]=M1[j][i];
	
	//M1*M2==M2*M1,cosidering part 1 as M3 and part 2 as M4
	int M3[m][m];
		for (i=0;i<m;i++)
		{
			for(j=0;j<m;j++)
			{
				M3[i][j]=0;
				for(k=0;k<m;k++)
				{
					M3[i][j]+=M1[i][k]*M2[k][j];
				}
			}
		}
		
	int M4[m][m];
		for (i=0;i<m;i++)
		{
			for(j=0;j<m;j++)
			{
				M4[i][j]=0;
				for(k=0;k<m;k++)
				{
					M4[i][j]+=M2[i][k]*M1[k][j];
				}
			}
		}
		
	//checking M3==M4
	int flag=1;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(M3[i][j]!=M4[i][j])
			{
				flag=0;
				break;
			}
		}
	}
	if(flag)
		printf("ORTHODOX");
		else
		printf("NOT");
		
	return 0;
}
