#include<stdio.h>
int main()
	{
		int k=8,m=7;
		--k<=m?m++:m--;
		printf("%d",m);
		return 0;
	}
