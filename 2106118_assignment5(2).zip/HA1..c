/*
Jayash prem 2106118
HA1. WAP to perform ternary search on a array for a search key.
Date:06/04/22                      
 */
#include<stdio.h>
int main()
	{
	int N,i,j,temp,key;
	printf("Enter the number of element in the array: ");
	scanf("%d",&N);
	int arr[N];

	for(i=0;i<N;i++)
	{
		printf("Enter %d element of the array: ",i+1);
		scanf("%d",&arr[i]);
	}
	
	printf("enter the key to search: ");
	scanf("%d",&key);
	
	//ternary search start
	
	int l =0;
	int r=N-1;
	int mid1,mid2;
	int found=-1;
	while(r>=l)
	{
		mid1=l+(r-l)/3;
		mid2=r-(r-l)/3;
		
		if(arr[mid1]==key)
		found=mid1;
		if(arr[mid2]==key)
		found=mid2;
		
		if(key<arr[mid1])
			r=mid1-1;
		else if(key>arr[mid2])	
			l=mid2+1;
		else
		{
			l=mid1+1;
			r=mid2-1;
		}
		
	}
	if(found==-1)
		printf("%d not present in the array ",key);
	else
		printf("%d present in the array at the position [%d]",key,found+1);

	return 0;
	}
