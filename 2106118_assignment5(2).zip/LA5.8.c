/*
Jayash prem 2106118
program:LA8. WAP to sort an array using bubble sort algorithm.
Date:06/04/22                      
 */
#include<stdio.h>
int main()
{
int N,i,j,temp;
printf("Enter the number of element in the array: ");
scanf("%d",&N);
int arr[N];

for(i=0;i<N;i++)
{
printf("Enter %d element of the array: ",i+1);
scanf("%d",&arr[i]);
}
int s=0;
//BUBBLE SORT

for(i=0;i<N-1 &&s==0;i++)
{
	s=1;
	for(j=0;j<(N-i)-1;j++)
	  if(arr[j]>arr[j+1])
		{
		temp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=temp;
		s=0;
		}
}

//output
printf("Sorted array:\n");
for(i=0;i<N;i++)
	printf("%d\t",arr[i]);

return 0;
}

