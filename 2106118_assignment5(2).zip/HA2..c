/*
Jayash prem 2106118
HA2. WAP to sort an array using insertion sort algorithm
Date:06/04/22                      
 */
#include<stdio.h>
int main()
	{
	int key,i,N,j;
	printf("ENter the number of element in the aray: ");
	scanf("%d",&N);
	
	int arr[N];
	
	for(i=0;i<N;i++)
		{
			printf("ENter the array element %d: ",i+1);
			scanf("%d",&arr[i]);
		}
	
	for(i=0;i<N;i++)
	{
		key=arr[i];
		j=i-1;
		while(key<arr[j]&&j>=0)
		{
			arr[j+1]=arr[j];
			j--;
		}
		arr[j+1]=key;
	}
		printf("\nsorted arry with selection sort technique:\n");
	for(i=0;i<N;i++)
		printf("%d\t",arr[i]);

	return 0;
}

