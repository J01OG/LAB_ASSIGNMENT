/*
Jayash prem 2106118
program:LA2. WAP to find first and second largest in an array.
Date:06/04/22                      
 */
#include<stdio.h>
int main()
	{
	int key,i,N;
	printf("ENter the number of element in the aray: ");
	scanf("%d",&N);
	
	int arr[N];
	
	for(i=0;i<N;i++)
		{
			printf("ENter the array element %d: ",i+1);
			scanf("%d",&arr[i]);
		}
		int max=arr[0],max2=arr[1];
		
		for(i=0;i<N;i++)
		{
			if(arr[i]>max)
			{
			max2=max;
			max=arr[i];	
			}
		}
printf("largest number : %d\n",max);
printf("Second largest number: %d",max2);
	return 0;
	}
