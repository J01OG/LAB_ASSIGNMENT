/*
Jayash prem 2106118
program:LA4. WAP to perform binary search on a array for a search key.
Date:06/04/22                      
 */
#include<stdio.h>
int main()
	{
	int key,i,N,j,flag=0;
	printf("ENter the number of element in the aray: ");
	scanf("%d",&N);
	
	int arr[N];
	
	for(i=0;i<N;i++)
		{
			printf("ENter the array element %d: ",i+1);
			scanf("%d",&arr[i]);
		}
	printf("Enter the element to find: ");
	scanf("%d",&key);
	
	int U=N-1;
	int L=0;
	int M=(U-L)/2;
	int found=-1;
	
	while(L<=U)
		{
			M=L+(U-L)/2;
			if(arr[M]==key)
			{	
				found=M;break;
			}
			if(arr[M]<key)
				L=M+1;
			else
			U=M-1;
		}
if(found==-1)
	printf("%d not found in array",key);
else
	printf("%d found in the array at postion [%d]",key,found+1);

	return 0;
	}
