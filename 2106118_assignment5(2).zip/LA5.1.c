/*
Jayash prem 2106118
program:LA1. WAP to print fibonacci series using arrays.                          
Date:06/04/22                        
 */
#include<stdio.h>
int main()
	{
	int i,a=-1,b=1,c=a+b,N;
	//INPUT
	printf("ENTER THE VALUE OF N: ");
	scanf("%d",&N);
	int arr[N];
	//CALC
	for(i=0;i<N;i++)
		{
		arr[i]=c;
		a=b;
		b=c;
		c=a+b;
		}
	//OUTPUT
	for(i=0;i<N;i++)
		printf("%d\t",arr[i]);
	return 0;
	}


