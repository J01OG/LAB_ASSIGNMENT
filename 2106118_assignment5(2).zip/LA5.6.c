/*
Jayash prem 2106118
program:LA6. WAP to print binary equivalent of a given decimal number using arrays.
Date:06/04/22                      
 */
#include<stdio.h>
int main()
	{
		int bin,i;
		int arr[16];
		printf("Enter a decimal number: ");
		scanf("%d",&bin);
		int c=0;
		while(bin!=0)
		{
			arr[c++]=bin%2;
			bin/=2;
		}

printf("BINary equavlnt: ");
	for(i=c-1;i>=0;i--)
		printf("%d",arr[i]);
	return 0;
	}
