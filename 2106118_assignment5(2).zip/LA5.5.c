/*
Jayash prem 2106118
program:
LA5. WAP to print odd and even numbers in a array.
Date:06/04/22                      
 */
#include<stdio.h>
int main()
	{
	int N,i;
	//INPUT
	printf("ENTER THE VALUE OF N: ");
	scanf("%d",&N);
	int arr[N];
	for(i=0;i<N;i++)
		{
			printf("enter %d element : ",i+1);
			scanf("%d",&arr[i]);
		}
	//OUTPUT EVEN
	printf("EVEN:\n");
	for(i=0;i<N;i++)
		{
		if(arr[i]%2==0)
			printf("%d\t",arr[i]);
		}
	printf("\nODD:\n");
	//OUTPUT
	for(i=0;i<N;i++)
		if(arr[i]%2!=0)
			printf("%d\t",arr[i]);
	return 0;

	return 0;
	}
