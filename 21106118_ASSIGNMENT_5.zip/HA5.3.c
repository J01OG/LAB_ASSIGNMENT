/*
Jayash prem 2106118
program:HA5.3 WAP to find the median of a list of numbers.                         
Date:05/04/22                        
 */
#include<stdio.h>
int main()
	{
		float m;
		int i,n,c;
		//input
		printf("how many element?ENTER: ");
		scanf("%d",&n);
		int arr[n];
		//array input
		for(i=0;i<n;i++)
			{
				printf("ENTER ELEMENT %d: ",i+1);
				scanf("%d",&arr[i]);
			}
		//calc
		if(n%2!=0)
			printf("MEDIAN:%d",arr[n/2]);
		else
			{
				c=n/2;
				m=(float)(arr[c]+arr[c+1])/2.0;
				printf("MEDIAN: %0.2f",m);
			}
	return 0;
	}
