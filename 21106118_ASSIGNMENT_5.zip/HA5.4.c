/*
Jayash prem 2106118
program:HA5.4 WAP to find the standard deviation of a list of numbers.                         
Date:05/04/22                        
 */
#include<stdio.h>
#include<math.h>
int main()
	{
		int i,N;
		int sigx=0,sigx2=0;
		float dev;
		printf("enter the value of N for number of element :");
		scanf("%d",&N);
		int arr[N];
		//input and cal
		for(i=0;i<N;i++)
			{
				printf("ENTER ELEMENT %d: ",i+1);
				scanf("%d",&arr[i]);
				sigx+=arr[i];
				sigx2+=pow(arr[i],2);
			}
		//cal
		N=N-1;
		dev=(float)sqrt((sigx2/N)-pow((sigx/N),2));
		//print
		dev=sqrt(dev);
		printf("DEVIATION: %0.4f ",dev);

	return 0;
	}
