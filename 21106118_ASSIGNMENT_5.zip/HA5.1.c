/*
Jayash prem 2106118
program:HA5.1 WAP to swap first element with last, second element with second last and so on, stored in an array.                               
Date:05/04/22                        
 */
#include<stdio.h>
int main()
	{
		int n,i,c,d;
		//array size input:
		printf("Enter number of input size: ");
		scanf("%d",&n);
		if(n%2!=0)
			printf("uneven input cant do rearanging;");
		else
			{
				//input
				int arr[n],darr[n];
				for(i=0;i<n;i++)
					{
						printf(" enter %d element of array: ",i+1);
						scanf("%d",&arr[i]);
					}
				//swaping
				c=n-1;
				for(i=0;i<c;i++)
					darr[i]=arr[c--];
				d=0;
				for(i=n-1;i>=c;i--)
					darr[i]=arr[d++];			
		//DISPLAY
		printf("OLD ARRAY:\n");
	for(i=0;i<n;i++)
		printf("%d\t",arr[i]);
	printf("\n ARRAY AFTER SWAP:\n");
	for(i=0;i<n;i++)
		printf("%d\t",darr[i]);
	}
	return 0;
	}
