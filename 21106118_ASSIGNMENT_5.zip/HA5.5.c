/*
Jayash prem 2106118
program:HA5.5 WAP to sort 3 elements stored in an array without using any sorting algorithm.                         
Date:05/04/22                        
 */
#include<stdio.h>
int main()
	{
		printf("ENTER value:");
		int arr[2];
		int a,b,c,i;
		for(i=0;i<3;i++)
			{
				printf("Enter %d ELEMENT OF ARRAY: ",i+1);
				scanf("%d",&arr[i]);
			}
		a=arr[0];b=arr[1];c=arr[2];
	if(a>b&&a>c)
	{
		arr[0]=a;
		if(b>c)
			arr[1]=b;arr[2]=c;	
		if(c>b)
			arr[1]=c;arr[2]=b;
	}	
	else if(b>c)
	{
		arr[0]=b;
			if(a>c)
				arr[1]=a;arr[2]=c;
			if(c>a)
				arr[2]=a;arr[1]=a;
	}
	else
	{
		arr[0]=c;
			if(a>b)
				arr[1]=a;arr[2]=b;
			if(b>a)
				arr[1]=b;arr[2]=a;
	}
	printf("sorted List:");
	for(i=0;i<2;i++)
		printf("%d\t",arr[i]);
	return 0;
	}
