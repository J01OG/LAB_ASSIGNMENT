/*
Jayash prem 2106118
program:HA5.2 WAP to find out the second largest element stored in an array of 20 integers.                         
Date:05/04/22                        
 */
#include<stdio.h>
#define N 20
int main()
	{
		int max,max2,i;
		int arr[N];
		//input
		for(i=0;i<N;i++)
			{
				printf("Enter %d ELEMENT OF ARRAY: ",i+1);
				scanf("%d",&arr[i]);
			}
			max=arr[0];max2=arr[0];
		//calc
		for(i=0;i<N;i++)
		{
			if(arr[i]>max)
				{
					max2=max;
					max=arr[i];
				}
		}
		//display
		printf("SECOND LARGEST NUMBER: %d",max2);
		
	return 0;
	}
