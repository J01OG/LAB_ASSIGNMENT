/*
Jayash prem 2106118
program:LA5.4 WAP to swap the pair of elements starting from beginning.                         
Date:05/04/22                        
 */
#include<stdio.h>
int main()
	{

	int n,i,max;
	printf("Enter the size of array(N): ");
	scanf("%d",&n);
	if(n%2!=0)
	printf("cant do swapping odd number of array");
	else
	{	
		int arr[n];
		int darr[n];
	//input
		for(i=0;i<n;i++)
		{
			printf("ENTER %d element of ARRAY : ",i+1);
			scanf("%d",&arr[i]);
		}
	//0-1,swaping
		for(i=0;i<n;i+=2)
			darr[i]=arr[i+1];				
		for(i=1;i<n;i+=2)
			darr[i]=arr[i-1];	
	//display
		printf("old array without swaping:\n");
		for(i=0;i<n;i++)
			printf("%d\t",arr[i]);
		
		printf("\nAfter swaping:\n");
		for(i=0;i<n;i++)
			printf("%d\t",darr[i]);
	}
		return 0;
}
