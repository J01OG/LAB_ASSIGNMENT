/*
Jayash prem 2106118
program:LA5.1 WAP to input 10 integers into an array of size 10. Print all elements.                         
Date:05/04/22                        
 */
#include<stdio.h>
int main()
	{
	int arr[10],i;
	//INPUT
	for(i=0;i<10;i++)
		{
			printf("ENTER %d element of ARRAY : ",i+1);
			scanf("%d",&arr[i]);
		}
	//OUTPUT
	for(i=0;i<10;i++)
		printf("ELEMETNT NO %d: is %d\n",i+1,arr[i]);
	return 0;
	}
