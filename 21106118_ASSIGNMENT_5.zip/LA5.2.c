/*
Jayash prem 2106118
program:LA5.2 WAP to store max. 100 numbers into an array. Print all the elements that are three digit even integers.                         
Date:05/04/22                        
 */
#include<stdio.h>
#define MAX 100
int main()
	{
		int arr[MAX],i,c=0,n;
		for(i=0;i<MAX;i++)
		{
			printf("ENTER %d element of ARRAY : ",i+1);
			scanf("%d",&arr[i]);
		}
		
		for(i=0;i<MAX;i++)
			{
				c=0;
				n=arr[i];
				while(n>0)
					{
						c++;
						n/=10;
					}
				if(c==3)
				{
					if(arr[i]%2==0)
						printf("%d \n",arr[i]);
				}	
			}

	return 0;
	}
