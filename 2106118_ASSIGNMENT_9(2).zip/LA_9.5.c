/*
JAyash prem
LA9.5 WAP to sort an array using Pointer.
18/05/22
*/
#include<stdio.h>
int main()
{
	int i,j,temp,n;
	
	printf("ENTEER LENGHT  ");
	scanf("%d",&n);
	int arr[n];
	printf("enter array: ");
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
	
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(*(arr+i)>*(arr+j))
			{
				temp=*(arr+j);
				*(arr+j)=*(arr+i);
				*(arr+i)=temp;
			}
		}
	}
	printf("SORTED LIST:\n");
	for(i=0;i<n;i++)
		printf("%d\t",*(arr+i));
	return 0;
}
