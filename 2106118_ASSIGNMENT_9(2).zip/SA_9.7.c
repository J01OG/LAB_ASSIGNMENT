/*
JAyash prem
SA9.7 WAP to store n elements in an array using dynamic memory allocation and print the elements
using pointer.
18/05/22
*/
#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,*a,i,max;
	printf("enter number of elment of the array: ");
	scanf("%d",&n);
	a=(int*)malloc(n*sizeof(int));
	if(a==NULL)
	{
		printf("MEMORY ALLOCATION UNSUCESDULL");
		exit(0);
	}
	else
	{
		printf("\ENTER THE ARRAY ELEMENT ONE by one:\n");
		for(i=0;i<n;i++)
		{
			scanf("%d",(a+i));
		}
		
		//display
		for(i=0;i<n;i++)
			printf("%d\t",*(a+i));
	}

	return 0;
}
