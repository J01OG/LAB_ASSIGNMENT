/*
JAyash prem
LA9.7 WAP to print a string in reverse using a pointer.
18/05/22
*/
#include<stdio.h>
int main()
{
	char str[100];
	char *ptr;
	int i;
	printf("Enter a string:");
	gets(str);
	ptr=str+strlen(str)-1;
	printf("reverse string:");
	for(i=0;i<strlen(str);i++)
		{
		printf("%c",*ptr);
		ptr--;
		}
	
	return 0;
}
