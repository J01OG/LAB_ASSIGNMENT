/*
JAYASH PREM
HA9.1 WAP to change the value of constant integer using pointers.
24/05/2022
*/
#include <stdio.h>
int main()
{   
    const int a=10;     //declare and assign constant integer
    int *p;             //declare integer pointer
    p=&a;               //assign address into pointer p
     
    printf("Before changing - value of a: %d",a);
     
    *p=20;
     
    printf("\nAfter  changing - value of a: %d",a);
     
    return 0;
}

