/*
JAyash prem
SA9.5 WAP to print a string using pointer.
18/05/22
*/
#include<stdio.h>
int main()
{
	
	char str[100];
	char *ptr;
	int i;
	printf("Enter a string:");
	gets(str);
	ptr=str;
	printf("Entered string:");
	while(*ptr!='\0')
	{
		printf("%c",*ptr);
		ptr++;
	}
	
	
	return 0;
}
