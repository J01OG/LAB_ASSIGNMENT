/*
JAyash prem
SA9.6 WAP to count vowels in a string using pointer.
18/05/22
*/
#include<stdio.h>
int main()
{
	char str[100];
	char *ptr;
	int vc=0;
	printf("enter a string: ");
	gets(str);
	ptr=str;
	
	while(*ptr!='\0')
	{
		if(*ptr=='A'||*ptr=='E'||*ptr=='I'||*ptr=='O'||*ptr=='U'||*ptr=='a'||*ptr=='e'||*ptr=='i'||*ptr=='o'||*ptr=='u')	
			vc++;
		ptr++;
	}	
	printf("NUmber of vowel:%d",vc);
	return 0;
}
