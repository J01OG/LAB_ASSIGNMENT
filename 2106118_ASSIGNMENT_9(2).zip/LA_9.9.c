/*
JAyash prem
LA9.9 WAP to bubble sort array elements declared dynamically using call by reference.
18/05/22
*/
void bubble_sort(int *a,int n)
{
	int i,j,temp;
	for(i=1;i<n;i++)
	{
			for(j=0;j<n-i;j++)
			{
				if(*(a+j)<*(a+j+1))
				{
					temp=*(a+j);
					*(a+j)=*(a+j+1);
					*(a+j+1)=temp;
				}
			}
	}
}

#include<stdio.h>
int main()
{
	int i,n;
	printf("ENTEER LENGHT  ");
	scanf("%d",&n);
	int arr[n];
	printf("enter array: ");
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);	
		
	bubble_sort(&arr,n);	
	printf("value after bubble sort\n");
	
	for(i=0;i<n;i++)
		printf("%d\t",*(arr+i));	
	return 0;
}
