#include<stdio.h>
#define max 10
int main()
{
	int *a;
	*a=&max;
	*a+=2;
	printf("%d",*a);
	return 0;
}

