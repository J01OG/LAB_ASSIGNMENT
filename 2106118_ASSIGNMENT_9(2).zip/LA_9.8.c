/*
JAyash prem
LA9.8 WAP to find the largest element stored in an array of n elements by using dynamic memory
18/05/22
*/
#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,*a,i,max;
	printf("enter number of elment of the array: ");
	scanf("%d",&n);
	a=(int*)malloc(n*sizeof(int));
	if(a==NULL)
	{
		printf("MEMORY ALLOCATION UNSUCESDULL");
		exit(0);
	}
	else
	{
		printf("\ENTER THE ARRAY ELEMENT ONE by one\n:");
		scanf("%d",(a));
		max=*a;
		for(i=1;i<n;i++)
		{
			scanf("%d",(a+i));
			if(max<*(a+i))
				max=*(a+i);
		}
	printf("largest value: %d",max);
	}

	return 0;
}
