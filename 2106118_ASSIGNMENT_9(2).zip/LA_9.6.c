/*
JAyash prem
LA9.6 WAP to count vowels and consonants in a string using pointer.
18/05/22
*/
#include<stdio.h>
int main()
{
	char str[100];
	char *ptr;
	int vc=0,c=0;
	printf("enter a string: ");
	gets(str);
	ptr=str;
	
	while(*ptr!='\0')
	{
		if(isalpha(*ptr))
			if(*ptr=='A'||*ptr=='E'||*ptr=='I'||*ptr=='O'||*ptr=='U'||*ptr=='a'||*ptr=='e'||*ptr=='i'||*ptr=='o'||*ptr=='u')	
				vc++;
			else
				c++;
		ptr++;
	}	
	printf("NUmber of vowel:%d\n",vc);
	printf("nmber of consnatnt:%d ",c);
	return 0;
}
