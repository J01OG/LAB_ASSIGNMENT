//WAP to read the contents of a text file given by user.
#include<stdio.h>
int main()
{
    FILE * f;
    char s[255];
    f = fopen("SA11-1.txt","r");
    fgets(s,sizeof(s),f);
    printf("File Contains:~\n%s",s);
    fclose(f);
}