/*
JAYASH PREM
HA11.1 WAP which produces its own source code as its output.
*/

#include <stdio.h>
int main() {
    FILE *fp;
    int c;
   	char file[20];
   	
    // open the current input file
    fp = fopen(__FILE__,"r");
	
    do {
         c = getc(fp);   // read character 
         putchar(c);     // display character
    }
    while(c != EOF);  // loop until the end of file is reached this is ha1
    
    fclose(fp);
    return 0;
}
