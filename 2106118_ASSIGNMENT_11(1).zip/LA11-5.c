//WAP to print the content of a file in reverse order.
#include<stdio.h>
#include<string.h>
int main()
{
    FILE * f;
    char s[255];
    int i;
    f = fopen("SA11-1.txt","r");
    fgets(s,sizeof(s),f);
    fclose(f);
    i = strlen(s) - 1;
    printf("File Contains:~ ");
    while (i >= 0)
    {
        printf("%c",s[i]);
        i--;
    }
}