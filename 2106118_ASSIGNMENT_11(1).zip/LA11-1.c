/*WAP to read roll number, name and marks data of n number of students from user
and store them in a file. If the file previously exits, add the information of n students.*/
#include<stdio.h>
int main()
{
    FILE * f;
    int n, marks, count;
    char name[20];
    f = fopen("LA11-1.txt","w");
    printf("Enter Number Of Students:~");
    scanf("%i",&count);
    for (int i = 0; i < count; i++)
    {
        fputs("\n\n--Student Entry--\n",f);
        printf("Enter Information Of %ith Student\n",i+1);
        printf("Enter Name:~ \n");
        scanf("\n%s",name);
        fputs("Name:~ ",f);
        fputs(name,f);
        printf("Enter Roll No.:~ ");
        scanf("%i",&n);
        fprintf(f,"\nRoll No.:~ %i",n);
        printf("Enter Marks:~ ");
        scanf("%i",&marks);
        fprintf(f,"\nMarks:~ %i",marks);
    }
    fclose(f);
}