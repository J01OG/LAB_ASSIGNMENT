/*WAP to copy the contents of two files named as source1.txt and source2.txt into a third file
dest.txt.*/
#include<stdio.h>
int main()
{
    FILE * f;
    char s[255], n[255];
    f = fopen("SA11-1.txt","r");
    fgets(s,sizeof(s),f);
    fclose(f);
    f = fopen("text.txt","r");
    fgets(n,sizeof(n),f);
    fclose(f);
    f = fopen("LA11-2.txt","w");
    fputs(s,f);
    fputs("\n",f);
    fputs(n,f);
    fclose(f);
    printf("File Contains:~\n%s\n%s",s,n);
    printf("\nFile Content Is Copied");
}