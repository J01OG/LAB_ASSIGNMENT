//WAP to compare contents of two files and display appropriate message.
#include<stdio.h>
int main()
{
    FILE * f;
    char s[255], n[255];
    int i = 0, x = 1;
    f = fopen("SA11-1.txt","r");
    fgets(s,sizeof(s),f);
    fclose(f);
    f = fopen("SA11-4.txt","r");
    fgets(n,sizeof(n),f);
    fclose(f);
    while (s[i] != '\0' && n[i] != '\0')
    {
        if (s[i] != n[i])
        {
            x = 0;
            break;
        }
        i++;
    }
    if (x == 1){printf("Files Are Identical");}
    else{printf("Files Have Different Values");}
}