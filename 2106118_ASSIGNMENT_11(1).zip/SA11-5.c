//WAP to convert all characters in uppercase of a file.
#include<stdio.h>
int main()
{
    FILE * f;
    int i = 1;
    char s[255];
    f = fopen("SA11-1.txt","r");
    fgets(s,sizeof(s),f);
    while (s[i] != '\0')
    {
        if (s[i] > 96 || s[i] < 123)
        {
            s[i]-=32;  
        }
        i++;
    }
    printf("File Contains:~\n%s",s);
    fclose(f);
}