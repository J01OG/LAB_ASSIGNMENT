/*WAP to count the number of characters, number of lines, blankspaces, tabs in a given text
file.*/
#include<stdio.h>
int main()
{
    FILE * f;
    int i = 0, c = 0, n = 0, x = 0, y = 0;
    char s[255];
    f = fopen("text.txt","r");
    fgets(s,sizeof(s),f);
    while (s[i] != '\0')
    {
        if (s[i] < 91 || s[i] > 64 || s[i] > 96 || s[i] < 123)
        {
            c++;
        }
        if (s[i] == '\n')
        {
            n++;
        }
        if (s[i] == ' ')
        {
            x++;
        }
        if (s[i] == '\t')
        {
            y++;
        }
        i++;
    }
    printf("Number Of Characters, lines, blankspaces, Tabs In A Given Text File Is :~ ");
    printf("%i, %i, %i, %i respectively",c,n,x,y);
    fclose(f);
}