//WAP to replace first letter of every word of the contents of a file with capital letter.
#include<stdio.h>
int main()
{
    FILE * f;
    char s[255];
    int i = 0;
    f = fopen("text.txt","r");
    fgets(s,sizeof(s),f);
    fclose(f);
    if (s[i] > 96){s[i] -= 32;}
    while (s[i] != '\0')
    {
        if (s[i] == ' ' || s[i] == '\n')
        {
            if (s[i+1] > 96){s[i+1] -= 32;}
        }
        i++;
    }
    printf("File Contains:~\n%s",s);
}