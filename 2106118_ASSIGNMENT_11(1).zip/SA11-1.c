//WAP to create a file & write some data in it.
#include<stdio.h>
int main()
{
    FILE * f;
    f = fopen("SA11-1.txt","w");
    fputs("Hello File",f);
    printf("File Is Created And String Is Written");
    fclose(f);
}