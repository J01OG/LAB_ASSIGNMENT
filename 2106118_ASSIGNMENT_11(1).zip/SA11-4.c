//WAP to copy the contents of one file in to another file.
#include<stdio.h>
int main()
{
    FILE * f;
    char s[255];
    f = fopen("SA11-1.txt","r");
    fgets(s,sizeof(s),f);
    fclose(f);
    f = fopen("SA11-4.txt","w");
    fputs(s,f);
    fclose(f);
    printf("File Contains:~\n%s",s);
    printf("\nFile Content Is Copied");
}