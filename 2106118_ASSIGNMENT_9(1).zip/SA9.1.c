/*
JAYASH PREM
SA9.1 WAP to create, initialize, assign and access a pointer variable.
17/05/2022
*/


#include <stdio.h>

int main () 
	{
	int a=5;
	int *p1;
	*p1=&a;
	
   return 0;
}
